import sqlite3

from flask import Flask, render_template, redirect, request


db = sqlite3.connect('datab.db')
c = db.cursor()
##c.execute(""" CREATE TABLE tovar (
##        id integer primary_key,
##        title String,
##        price integer,
##        description text
##)""")

#c.execute("""INSERT INTO users (name, data_pas, cash, description_tovaru) VALUES ('Fedya', 'fedja pypkin vasulovuch CE 459832', 100, 'Намети Tramp i Naturehike')""")

    ##(tabl - obli_C_ v bd - obli_K_) insert database
#c.execute("""INSERT INTO tovar (title, price, description) VALUES ('Намети Terra Incognita', 50, 'Намети 2-х місна, 3-х сезонна'),
#     ('Намети Tramp ', 50, 'Намети 3-х місна,4-х сезонна'),                
#     ('Намети Naturehike', 50, 'Намети 3-х місна, 3-х сезонна'),
#     ('Намети Naturehike', 50, 'Намети 2-х місна, 3-х сезонна'),
#     ('Килимок Therm-A-Rest Z Lite', 30, 'Карімат гармошка'),
#     ('Спальний мішок Deuter', 40, 'Спальник t comfort 0, limit -5')
#""")

# update naturehike + p-3
#c.execute("UPDATE oblic SET title = 'Намети Naturehike p-3' WHERE description = 'Намети 3-х місна, 3-х сезонна'")

#vybirka
c.execute("SELECT * FROM Persons")
items = c.fetchall()
for el in items:
    print(el)

db.commit()

db.close()


