import sqlite3

from flask import Flask, render_template, redirect, request


db = sqlite3.connect('database.db')
c = db.cursor()

#c.execute(""" CREATE TABLE Tovar (
#        id integer primary_key,
#        title String(100),
#        price integer,
#        description text,
#        url String(200)
#)""")

#c.execute(""" CREATE TABLE Persons (
#        id integer primary_key,
#        name String(100),
#        data_pas String(100),
#        bron integer,
#        title String(100),
#        datetime Date
#)""")

#c.execute("""CREATE TABLE Profiles (
#        id integer primary_key,
#        name String(100),
#        bron integer,
#        title String(100),
#        datetime Date
#)""")

#c.execute("""INSERT INTO Persons (id, name, data_pas, bron, title, datetime) VALUES (1, 'Fedya    ', '   fedja pypkin vasulovuch CE 459832       ', 2, '      Намети Tramp ', ' 2022-08-07')""")

#c.execute("""INSERT INTO Profiles (id, name, bron, title, datetime) VALUES (1, 'Fedya      ', 2, '    Намети Tramp ', '  2022-08-07')""")
#c.execute("""INSERT INTO users (name, data_pas, cash, description_tovaru) VALUES ('Fedya', 'fedja pypkin vasulovuch CE 459832', 100, 'Намети Tramp i Naturehike')""")

    ##(tabl - obli_C_ v bd - obli_K_) insert database
#c.execute("""INSERT INTO Tovar (id, title, price, description, url) VALUES (1, 'Намети Terra Incognita', 50, 'Намети 2-х місна, 3-х сезонна','https://www.youtube.com/watch?v=pmBNrPojj8k'),
#     (2, 'Намети Tramp ', 50, 'Намети 3-х місна,4-х сезонна', 'https://www.youtube.com/watch?v=5PQGoXdZgmE'),                
#     (3, 'Намети Naturehike', 50, 'Намети 3-х місна, 3-х сезонна','https://www.youtube.com/watch?v=z_IHlyduvP4'),
#     (4, 'Намети Naturehike', 50, 'Намети 2-х місна, 3-х сезонна','https://www.youtube.com/watch?v=z_IHlyduvP4'),
#     (5, 'Килимок Therm-A-Rest Z Lite', 30, 'Карімат гармошка','https://www.youtube.com/watch?v=-8pe4gJIMKs'),
#     (6, 'Спальний мішок Deuter', 40, 'Спальник t comfort 0, limit -5','https://www.youtube.com/watch?v=Bpf5x-Vo418')
#""")

# update naturehike + p-3
#c.execute("UPDATE Persons SET datetime = '2022-08-07' WHERE id = 1")
#c.execute("DELETE FROM Persons where id == None")
#c.execute("UPDATE Profiles SET url = 'https://www.youtube.com/watch?v=pmBNrPojj8k' WHERE id = 1")

#vybirka
c.execute("SELECT * FROM Tovar")
items = c.fetchall()
for el in items:
    print(el)

c.execute("SELECT * FROM Persons")
items = c.fetchall()
for el in items:
    print(el)

c.execute("SELECT * FROM Profiles")
items = c.fetchall()
for el in items:
    print(el)


db.commit()

db.close()


